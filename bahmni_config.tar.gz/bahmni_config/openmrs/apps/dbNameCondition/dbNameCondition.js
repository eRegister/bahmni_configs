Bahmni.Common.Offline.dbNameCondition.get = function (provider, loginLocation) {
    return loginLocation;
};