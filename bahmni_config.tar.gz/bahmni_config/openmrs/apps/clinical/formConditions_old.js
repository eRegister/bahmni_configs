Bahmni.ConceptSet.FormConditions.rules = {
    'Diastolic Data' : function (formName, formFieldValues) {
        var systolic = formFieldValues['Systolic'];
        var diastolic = formFieldValues['Diastolic'];
        if (systolic || diastolic) {
            return {
                enable: ["Posture"]
            }
        } else {
            return {
                disable: ["Posture"]
            }
        }
    },

    'Systolic Data' : function (formName, formFieldValues) {
        var systolic = formFieldValues['Systolic'];
        var diastolic = formFieldValues['Diastolic'];
        if (systolic || diastolic) {
            return {
                enable: ["Posture"]
            }
        } else {
            return {
                disable: ["Posture"]
            }
        }
     },
//////////////////////////////////////////////////////////////////////////
//////////////////// Tuberculosis - Intake Form///////////////////////////
//////////////////////////////////////////////////////////////////////////
    'Genotypic test type performed' : function (formName, formFieldValues) {
	var genexpertTest = formFieldValues['Genotypic test type performed'];
	var conditions = {show: [], hide: []};
	switch (genexpertTest){
		case "GeneXpert test type":
			conditions.show.push("GeneXpert results");
			conditions.hide.push("Line Probe Assay results");
			break;

		case "Line Probe Assay test type":
			conditions.show.push("Line Probe Assay results");
			conditions.hide.push("GeneXpert results");
			break;
		default:
			conditions.hide.push("GeneXpert results", "Line Probe Assay results");
	}
	return conditions;
    },

    'Phenotypic Test type performed' : function (formName, formFieldValues) {
	var phenotipicTest = formFieldValues['Phenotypic Test type performed'];
	var conditions = {show: [], hide: []};
	if (phenotipicTest){
		conditions.show.push("Phenotypic Test Results (ZN or C)");
	} else {	
		conditions.hide.push("Phenotypic Test Results (ZN or C)");
	}
	return conditions;
    },

    'TB Transfer in' : function (formName, formFieldValues) {
        var conditionConcept = formFieldValues['TB Transfer in'];
        var conditions = {show: [], hide: []};

        if (conditionConcept == "Transfer In"){
            conditions.show.push("HIVTC, Transferred in from");
        } else {
            conditions.hide.push("HIVTC, Transferred in from");
        }

        return conditions;
    },

//////////////////////////////////////////////////////////////////////////
/////////////////////Tuberculosis - Followup Form/////////////////////////
//////////////////////////////////////////////////////////////////////////
    'TB Treatment outcome' : function (formName, formFieldValues) {
        var treatmentOutcome = formFieldValues['TB Treatment outcome'];
	var conditions = {enable: [], disable: []};	
        if (treatmentOutcome in {"Failed treatment": 0, "Failed treatment and is resistant": 0 }) {
            conditions.enable.push("TB Action taken for treatment Failures and/or Drug resistant patients"); 
        } else {
            conditions.disable.push("TB Action taken for treatment Failures and/or Drug resistant patients"); 
	}
	return conditions;
    },
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////HIV Care and Treatment - Intake/////////////////////////
///////////////////////////////////////////////////////////////////////////

    'HIVTC, Status at enrolment' : function (formName, formFieldValues) {
        var conditionConcept = formFieldValues['HIVTC, Status at enrolment'];
        var conditions = {show: [], hide: []};

	if (conditionConcept == "HIV Exposed Infant"){
            conditions.show.push("ART, HIV Exposed Baby");
        } else {
            conditions.hide.push("ART, HIV Exposed Baby");
        }

        return conditions;
    },

    'HIVTC, Prior ART' : function (formName, formFieldValues) {
        var conditionConcept = formFieldValues['HIVTC, Prior ART'];
        var conditions = {show: [], hide: []};

        if (conditionConcept == "Transfer In"){
            conditions.show.push("HIVTC, Transferred in");
        } else {
            conditions.hide.push("HIVTC, Transferred in");
        }

        return conditions;
    },

    'HTC, Pregnancy Status' : function (formName, formFieldValues) {
        var conditionConcept = formFieldValues['HTC, Pregnancy Status'];
        var conditions = {show: [], hide: [], enable: [], disable: []};

        if (conditionConcept == "Pregnancy"){
            conditions.show.push("Pregnancy Estimated Date of Delivery");
	    conditions.hide.push("Currently on FP");
        } else {
            conditions.hide.push("Pregnancy Estimated Date of Delivery");
            conditions.show.push("Currently on FP");
        }

        return conditions;
    },
   
    'Currently on FP' : function (formName, formFieldValues) {
        var conditionConcept = formFieldValues['Currently on FP'];
        var conditions = {show: [], hide: []};

        if (conditionConcept == "Yes"){
            conditions.show.push("HIVTC, FP methods used by the patient");
        } else {
            conditions.hide.push("HIVTC, FP methods used by the patient");
        }

        return conditions;
    },
   
    'ART Treatment interruption type' : function (formName, formFieldValues) {
        var conditionConcept = formFieldValues['ART Treatment interruption type'];
        var conditions = {show: [], hide: []};

        if (conditionConcept == "Stopped"){
            conditions.show.push("ART treatment interruption stopped reason");
        } else {
            conditions.hide.push("ART treatment interruption stopped reason");
        }

        return conditions;
    }

};

