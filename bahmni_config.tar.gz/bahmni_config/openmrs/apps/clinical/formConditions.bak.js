Bahmni.ConceptSet.FormConditions.rules = {
    'Diastolic Data' : function (formName, formFieldValues) {
        var systolic = formFieldValues['Systolic'];
        var diastolic = formFieldValues['Diastolic'];
        if (systolic || diastolic) {
            return {
                enable: ["Posture"]
            }
        } else {
            return {
                disable: ["Posture"]
            }
        }
    },

    'Systolic Data' : function (formName, formFieldValues) {
        var systolic = formFieldValues['Systolic'];
        var diastolic = formFieldValues['Diastolic'];
        if (systolic || diastolic) {
            return {
                enable: ["Posture"]
            }
        } else {
            return {
                disable: ["Posture"]
            }
        }
    },

    'Type of client' : function (formName, formFieldValues, patient) {
        var conditions = {show: [], hide: [], enable: [], disable: []};
	var patientAge = patient['age'];
        var patientGender = patient['gender'];

        if((patientGender == "F") && (patientAge > 12)) {
            conditions.show.push("HTC, Pregnancy Status");
        }else {
            conditions.hide.push("HTC, Pregnancy Status");
        }
        return conditions;
    },

    'HIVTC, Prior ART' : function (formName, formFieldValues) {
        var conditionConcept = formFieldValues['HIVTC, Prior ART'];

        var conditions = {show: [], hide: []};

        if (conditionConcept == "Transfer In"){
            conditions.show.push("HIVTC, Transferred in");
        }else {
            conditions.hide.push("HIVTC, Transferred in");
	}
        return conditions;
    },

   'HIVTC, Treatment substituted date' : function (formName, formFieldValues) {
        var conditionConcept = formFieldValues['HIVTC, Treatment substituted date'];
        var conditions = {enable: [], disable: [], show: [], hide: []};

        if (conditionConcept){
            conditions.enable.push("HIVTC, Adult 1st Line Regimen")
            conditions.enable.push("HIVTC, Adult 2nd Line Regimen")
            conditions.enable.push("HIVTC, Children 1st Line Regimen")
            conditions.enable.push("HIVTC, Children 2nd Line Regimen")
            conditions.enable.push("HIVTC, Adult 3rd Line Regimen")
            conditions.enable.push("HIVTC, Children 3rd Line Regimen")
            conditions.enable.push("HIVTC, Reason for treatment substitution");
        }else {
            conditions.disable.push("HIVTC, Reason for treatment substitution")
            conditions.disable.push("HIVTC, Adult 1st Line Regimen")
            conditions.disable.push("HIVTC, Adult 2nd Line Regimen")
            conditions.disable.push("HIVTC, Adult 3rd Line Regimen")
            conditions.disable.push("HIVTC, Children 1st Line Regimen")
            conditions.disable.push("HIVTC, Children 2nd Line Regimen")
            conditions.disable.push("HIVTC, Children 3rd Line Regimen");
        } 
        return conditions;
    },

    'HIVTC, Treatment switched date' : function (formName, formFieldValues) {
        var conditionConcept = formFieldValues['HIVTC, Treatment switched date'];

        var conditions = {enable: [], disable: []};

        if (conditionConcept){
            conditions.enable.push("HIVTC, Reason for treatment switch")
            conditions.enable.push("HIVTC, Name of Switched Regimem");
        }else {
            conditions.disable.push("HIVTC, Reason for treatment switch")
            conditions.disable.push("HIVTC, Name of Switched Regimem");
        }
        return conditions;
    },

    'HTC, Pregnancy Status' : function (formName, formFieldValues, patient) {
        var conditionConcept = formFieldValues['HTC, Pregnancy Status'];
        var patientAge = patient['age'];
        var patientGender = patient['gender'];

        var conditions = {show: [], hide: [], enable: [], disable: []};

        
	if(patientGender == "F" && conditionConcept == "Pregnancy"){
	    conditions.show.push("Pregnancy Estimated Date of Delivery");
            conditions.hide.push("Currently on FP");
	    conditions.hide.push("HIVTC, FP methods used by the patient");
	}
	else if((patientGender == "F" && patientAge > 12 && conditionConcept == "Pregnancy") || patientAge < 5) {
	    conditions.show.push("IMAM, MUAC");
	    if(patientAge < 5){
            	conditions.hide.push("Pregnancy Estimated Date of Delivery");
            	conditions.hide.push("Currently on FP");
            	conditions.hide.push("HIVTC, FP methods used by the patient");
            	conditions.hide.push("PMTCT, Referred if the status is unknown");
	    }
	} else {
	    conditions.hide.push("IMAM, MUAC");
            conditions.hide.push("Pregnancy Estimated Date of Delivery");
            conditions.hide.push("Currently on FP");
            conditions.hide.push("HIVTC, FP methods used by the patient");
	    conditions.hide.push("PMTCT, Referred if the status is unknown");	    
        }
        return conditions;
     },

     'TB Status': function(formName, formFieldValues){
	var conditionConcept = formFieldValues['TB Status'];
	var conditions = { show: [], hide: [] };

	if(conditionConcept == "Suspected / Probable") {
	    conditions.show.push("TB Suspect signs");
	} else {
	    conditions.hide.push("TB Suspect signs");
	}
	return conditions;
     },
     
  /*---------------------HIV Care and Treatment-------------------*/

     'Transfer Out to another site': function(formName, formFieldValues){
        var conditionConcept = formFieldValues['Transfer Out to another site'];
        var conditions = { show: [], hide: [] };

        if(conditionConcept == "Yes" ) {
            conditions.show.push("HIVTC, Transferred out");
        } else {
            conditions.hide.push("HIVTC, Transferred out");
        }
        return conditions;
     },

     'ART Treatment interruption type' : function (formName, formFieldValues) {
        var conditionConcept = formFieldValues['ART Treatment interruption type'];

        var conditions = {show: [], hide: []};

        if (conditionConcept == "Stopped"){
            conditions.show.push("ART treatment interruption stopped reason");
        }else {
            conditions.hide.push("ART treatment interruption stopped reason");
        }
      return conditions;
    },

    'HIVTC, ART Treatment Adherence' : function (formName, formFieldValues) {
          var conditionConcept = formFieldValues['HIVTC, ART Treatment Adherence'];

          var conditions = {show: [], hide: []};

          if ((conditionConcept == "Poor adherence") || (conditionConcept == "Fair adherence")){
              conditions.show.push("Poor or Fair ART adherence reason");
         } else {
            conditions.hide.push("Poor or Fair ART adherence reason");
          }
       return conditions;
    },

     'HIVTC, Status at enrolment' : function (formName, formFieldValues, patient) {
        var patientAge = patient['age'];
        var patientGender = patient['gender'];
	
        if (patientAge < 1) {
            return {
                show: ["ART, HIV Exposed Baby"]
            }
        } else {
            return {
                hide: ["ART, HIV Exposed Baby"]
            }
        }
    },
/*--------End of HIV Care and Treatment---------*/
};


